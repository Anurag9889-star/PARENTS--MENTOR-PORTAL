package com.university.parent.repository;

import com.university.parent.entity.Parent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ParentRepository extends JpaRepository<Parent, Long> {
    // Used to check if parent profile already exists during CSV upload
    Optional<Parent> findByUsername(String username);
}